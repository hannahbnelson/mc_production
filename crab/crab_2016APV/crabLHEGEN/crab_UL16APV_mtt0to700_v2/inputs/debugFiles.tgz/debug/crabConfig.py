from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crabLHEGEN'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'UL16APV_mtt0to700_v2'
config.section_('JobType')
config.JobType.psetName = 'TOP-RunIISummer20UL16wmLHEGENAPV-mtt0to700_cfg.py'
config.JobType.pluginName = 'PrivateMC'
config.JobType.numCores = 2
config.JobType.maxMemoryMB = 5000
config.JobType.eventsPerLumi = 1000
config.section_('Data')
config.Data.unitsPerJob = 1000
config.Data.outputPrimaryDataset = 'TT01j2l_SMEFTsim_LHEGEN_UL16APV_0to700'
config.Data.outLFNDirBase = '/store/user/hnelson/mc/ttbarEFT_Run2/UL16APV/LHEGEN/'
config.Data.splitting = 'EventBased'
config.Data.totalUnits = 10000000
config.section_('Site')
config.Site.storageSite = 'T3_US_NotreDame'
config.section_('User')
config.section_('Debug')
